README — مخمخ ستور link page
--------------------------------
هذا مجلد جاهز لرفعه كصفحة صغيرة (single page) تظهر الأزرار: إنستغرام - فيسبوك - واتساب.
الملفات المضمّنة:
- index.html
- style.css
- logo.jpg (الشعار الذي أرسلتَه)
- deploy_instructions.txt

خطوات سريعة لعرض الصفحة على الإنترنت (Netlify المجاني - أو GitHub Pages):
1) تسجيل دخول إلى https://www.netlify.com (أو اصنع حساب جديد).
2) من لوحة Netlify اختر "Sites" → "Add new site" → "Deploy manually".
3) اسحب ملف ZIP الموجود في هذا الحزمة إلى منطقة السحب (drag and drop).
4) Netlify سيعطيك رابط مباشر (مثل https://something.netlify.app) — هذا هو الرابط الذي تضعه في QR Code.
